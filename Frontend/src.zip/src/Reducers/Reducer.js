
const initialState = {
    Username: '',
    Password: '',
    LoginSuccess: false,
};

const loginReducer = (state = initialState, action) => {
    if (action.type === 'Login') {
        console.log("In Login Reducer checking action.payload: ", action.payload);
        return {
            ...state,
            Username: action.payload.Username,
            Password: action.payload.Password,
            LoginSuccess: action.payload.Username === action.payload.Password ? true : false
        };
    }
    return state;
}

export default loginReducer;