import { configureStore } from '@reduxjs/toolkit';
import loginReducer from '../Reducers/Reducer';
console.log("In Store with loginreducer as : ", loginReducer);
export const store = configureStore(
  {reducer: {login: loginReducer}}
);
