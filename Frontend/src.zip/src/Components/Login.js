import React, { Component } from 'react'
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import { connect } from 'react-redux';
import { login } from '../Actions/LoginAction';
import { Grid } from '@mui/material';
import { store } from '../Stores/store';
import { Card } from '@mui/material';
import { CardContent } from '@mui/material';
import {Typography} from '@mui/material';
class Login extends Component {
    setField = (event) => {
        this.setState({ [event.target.name]: event.target.value }, () => {
        })
    }

    submitForm = () => {
        console.log("In SubmitForm || Submit Button Clicked with state: ", this.state);
        console.log("In submitform : ", this.state);
        this.props.login(this.state.Username, this.state.Password);
        console.log("Store dot getState() gives : ", store.getState());
        if (!store.getState().login.LoginSuccess) {
            alert("Login Unsuccessful");
        }
        else {
            alert("Login Successful");
        }
    }

    render() {
        return (
            <>
                <Grid container spacing={2} item sm={12}
                    sx={{
                        display: 'flex',
                        flexWrap: 'wrap',
                        marginX: "auto",
                        marginY: "10%",
                        fontFamily: "Times New Roman",
                        paddingTop: "20px",
                        width: "40%",
                        minWidth: "300px"
                    }
                    }>

                    <Grid container>
                        <Card
                            variant='outlined'
                            sx={{
                                width: "fit-content",
                                marginY: "1%",
                                marginX: "auto",
                                borderRadius: "20px",
                                padding: "2%",
                                height: "auto"
                            }}>
                                <Typography sx={{marginLeft: "10px", fontWeight: "bold"}} variant='h6'>Log In</Typography>
                            <CardContent>
                                <Grid>
                                    <TextField name='Username' onChange={(event) => this.setField(event)} id="Username" label="Username" variant="filled" />
                                </Grid>
                                <Grid sx={{ marginY: "2%" }}>
                                    <TextField name='Password' onChange={(event) => this.setField(event)} id="Password" label="Password" variant="filled" />
                                </Grid>
                                <Grid sx={{ marginLeft: "auto", marginRight: "20px" }}>
                                    <Button variant="contained" onClick={this.submitForm} sx={{ margin: "10px" }}>Submit</Button>
                                </Grid>
                            </CardContent>
                        </Card>

                    </Grid>
                </Grid >
            </>
        )
    }
}
const mapStateToProps = (state) => {
    console.log("In MapStateToProps with state: ", state);
    return {
        Username: state.login.Username,
        Password: state.login.Password,
        LoginSuccess: state.login.LoginSuccess
    }
}
const mapDispatchToProps = (dispatch) => {
    console.log("Dispatch in mapDispatchToProps is : ", dispatch);
    return {
        login: (username, password) => dispatch(login(username, password))
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Login)