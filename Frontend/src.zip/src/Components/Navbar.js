import React, { Component } from 'react'
import { AppBar, Toolbar, Typography } from '@mui/material'
// import { Link } from 'react-router-dom'
export default class Navbar extends Component {
    render() {
        return (
            <>
                <AppBar sx={{ backgroundColor: 'black'}}>
                    <Toolbar>
                        <Typography sx={{fontWeight: "bolder"}}>LogIn System</Typography>
                    </Toolbar>
                </AppBar>
            </>
        )
    }
}